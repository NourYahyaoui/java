/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import utils.Texttospeech;

/**
 *
 * @author aymen
 */
public class testing {
    
    public static void main(String[] args) {
       System.out.println(System.getProperty("user.dir"));
        
    }
    
}
