/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;
/*import entites.Formation;
import entites.difficulté;
import services.ServiceFormation;*/

/**
 *
 * @author User
 */
public class MainTest {
    
    
    public static void main(String[] args) {
        System.out.println("in main");
        /*
        ServiceFormation sp = new ServiceFormation();
        System.out.println("création d'un objet Service Formation SUCCED");
        
        Formation F= new Formation();
        System.out.println(" objet Formation created SUCCED");
        F.setSujet("JAVA");
        F.setDescription("Cours de base de prog");
        F.setDifficulté(difficulté.DIFFICILE);
        F.setDurée(8);
        F.setIdPrerequis(Long.MIN_VALUE);
        F.setIdCompetence(Long.MIN_VALUE);
        F.setIdCategorie(Long.MAX_VALUE);
        
        
        sp.ajouter_formation(F);
       
    }*/
    
    }
}
