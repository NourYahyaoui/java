/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import entities.Recup;
import static gui.AuthController.connectedUser;
import java.security.Security;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import services.RecupService;

/**
 *
 * @author Nour
 */
public class Test2 {

    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));

    }

}
