/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package entites;

/**
 *
 * @author User
 */
public enum difficulté {
   facile, moyen , difficile;

    public static difficulté getFACILE() {
        return facile;
    }

    public static difficulté getMOYEN() {
        return moyen ;
    }

    public static difficulté getDIFFICILE() {
        return difficile;
    }

   
    
    
    
 
}
